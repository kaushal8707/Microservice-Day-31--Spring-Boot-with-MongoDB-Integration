package com.java.selfdeveloped.mongo.api.repository;
import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import com.java.selfdeveloped.mongo.api.model.Task;

public interface TaskRepository extends MongoRepository<Task,String> {

    List<Task> findBySeverity(int severity);

    @Query("{assignee : ?0}")
    List<Task> getTasksByAssignee(String assignee);
    
    @Query("{severity : ?0, storyPoint : ?1}")
    List<Task> getTasksBySeverityAndStoryPoint(int severity, int storyPoint); 
}


